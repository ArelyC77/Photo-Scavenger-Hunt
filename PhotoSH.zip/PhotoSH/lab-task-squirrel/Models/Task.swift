//
//  Task.swift
//  lab-task-squirrel
//
//  Created by Charlie Hieger on 11/15/22.
//

import UIKit
import CoreLocation

class Task {
    let title: String
    let description: String
    var image: UIImage?
    var imageLocation: CLLocation?
    var isComplete: Bool {
        image != nil
    }

    init(title: String, description: String) {
        self.title = title
        self.description = description
    }

    func set(_ image: UIImage, with location: CLLocation) {
        self.image = image
        self.imageLocation = location
    }
}

extension Task {
    static var mockedTasks: [Task] {
        return [
            Task(title: "Your favorite local restaurant 🍟",
                 description: "What's your go to food?"),
            Task(title: "Your favorite local coffee ☕️",
                 description: "What type of coffee do you order?"),
            Task(title: "Your go to location to visit 🇳🇮",
                 description: "What is your favorite spot here?"),
            Task(title: "Your favorite hiking spot 🥾",
                 description: "Where is the best place to be one with nature?")
        ]
    }
}
